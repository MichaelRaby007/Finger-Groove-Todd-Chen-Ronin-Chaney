
public class right {

}
