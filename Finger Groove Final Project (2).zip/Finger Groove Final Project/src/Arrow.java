import javax.swing.ImageIcon;

public class Arrow {

	private int x;
	private int y;
	private int w;
	private int h;
	private int dx;
	private ImageIcon arrow;
	
	
	
	public Arrow()
	{
		x=0;
		y=0;
		h=50;
		w=50;
		arrow = new ImageIcon("");
	}
	

	public Arrow(int xV, int yV, int width, int height, ImageIcon i) {
		x = 30;
		y = 50;
		w = width;
		h = height;
		arrow = new ImageIcon("up.png");
	
	}

	
	
	public int getX() 
	{
		return x;
	}
	 
	public int getY() 
	{
		return y;
	}	

	public int getH() 
	{
		return h;
	}
	 
	public int getW() 
	{
		return w;
	}	
	
	public void setX(int xV)
	{
		x += xV;
	}
	public void setY(int yV)
	{
		y += yV;
	}
	
	public void move()
	{
		x+=dx;
		
	}
	
	public void setDx(int dxFromGame)
	{
		dx= dxFromGame;
	}
}
