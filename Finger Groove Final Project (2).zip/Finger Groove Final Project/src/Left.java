
public class Left {

}
