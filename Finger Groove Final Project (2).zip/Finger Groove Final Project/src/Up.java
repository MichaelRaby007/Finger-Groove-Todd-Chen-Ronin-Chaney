import javax.swing.ImageIcon;

public class Up extends Arrow {
	
	public Up() {
		super();
	}


public Up(int x, int y) {
	super (x, y, 50, 50, new ImageIcon("up.png"));
	}
}